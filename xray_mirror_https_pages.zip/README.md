# X-Ray Mirror — HTTPS deployment package

This is the existing improved head-and-hand X-Ray Mirror, repackaged for HTTPS hosting. It does **not** add full-body anatomy or medical fracture detection. The original source is preserved in `original-reference.html`.

## Publish free with GitHub Pages

1. Create a **new** GitHub repository named `xray-mirror-web` (prefer private during development; verify your plan's Pages visibility and public-site implications). Do not upload patient information.
2. Upload all package contents to the repository root, including the `.github/workflows/pages.yml` file. GitHub's web upload may not preserve hidden folders; use Git or GitHub Desktop if needed.
3. In repository **Settings → Pages**, set **Build and deployment → Source: GitHub Actions**.
4. Open **Actions**, confirm the Pages workflow succeeds. Its deployment URL is the HTTPS site, usually `https://YOUR-USERNAME.github.io/xray-mirror-web/`.
5. On Android Chrome open the HTTPS URL (not a downloaded HTML file or `content://` address), tap **Start camera**, and allow camera access.
6. If denied earlier: Chrome → Settings → Site settings → Camera, and reset permission for the HTTPS site.

## Technical notes

- Camera access requires a secure context and user permission. Hosting on GitHub Pages provides HTTPS.
- Three.js and MediaPipe are loaded from third-party CDNs; internet access is required and CDN availability may affect loading.
- No patient data should be uploaded to this static demonstration.
- The camera cannot detect real fractures; this is illustrative anatomy only.
- Live camera behavior must be tested on a physical Android device.
